$(function(){var e=$(".notes").isotope({itemSelector:".note"})});
